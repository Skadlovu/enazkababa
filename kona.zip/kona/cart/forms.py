from django import forms
from ticket.models import TicketHolder

class AddToCartForm(forms.Form):
    quantity = forms.IntegerField(min_value=1, widget=forms.NumberInput(attrs={
        'class': 'form-control',
        'min': '1'
    }))

    def __init__(self, *args, **kwargs):
        self.ticket_details = kwargs.pop('ticket_details', None)
        super().__init__(*args, **kwargs)
        if self.ticket_details:
            self.fields['quantity'].widget.attrs['max'] = self.ticket_details.availability.first().tickets_remaining()

    def clean_quantity(self):
        quantity = self.cleaned_data['quantity']
        if self.ticket_details:
            available = self.ticket_details.availability.first().tickets_remaining()
            if quantity > available:
                raise forms.ValidationError(f"Only {available} tickets remaining!")
        return quantity

class TicketHolderForm(forms.ModelForm):
    class Meta:
        model = TicketHolder
        fields = ['name', 'surname', 'identity_number']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'surname': forms.TextInput(attrs={'class': 'form-control'}),
            'identity_number': forms.TextInput(attrs={'class': 'form-control'})
        }



class CreditCheckForm(forms.Form):
    total_income = forms.DecimalField(label='Total Income', max_digits=10, decimal_places=2)
    total_expenses = forms.DecimalField(label='Total Expenses', max_digits=10, decimal_places=2)
    facebook_profile = forms.URLField(label='Facebook Profile URL', required=False)
    twitter_profile = forms.URLField(label='X (Twitter) Profile URL', required=False)
    instagram_profile = forms.URLField(label='Instagram Profile URL', required=False)
    payslip = forms.FileField(label='Upload Recent Payslip', required=True)
    bank_statement = forms.FileField(label='Upload 3 months Bank Statements', required=True)
    
