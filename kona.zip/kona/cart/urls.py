from django.urls import path
from . import views

app_name = 'cart'

urlpatterns = [
    path('cart', views.cart_view, name='cart_view'),
    path('update/', views.update_cart_quantity, name='update_quantity'),
    path('remove/', views.remove_cart_item, name='remove_item'),
    path('prompt/', views.prompt_view, name='prompt'),
    path('choose-payment-method/', views.choose_payment_method, name='choose_payment_method'),
    path('credit-check/', views.credit_check, name='credit_check'),
    path('credit-details/<int:event_id>/', views.credit_details, name='credit_details'),
    path('payfast-payment/', views.checkout, name='cash_payment'),
    path('cart/add-to-cart/<int:ticket_details_id>/<int:quantity>/', views.add_to_cart, name='add_to_cart'),
    path('collect-ticketholder-info/', views.collect_ticketholder_info, name='collect_ticketholder_info'),
    path('cart/success/', views.payment_success, name='success'),
    path('cart/cancel/', views.payment_cancel, name='cancel'),
    path('cart/notify/', views.payfast_notify, name='notify'),
    #path('ticket-holder-info/', views.TicketHolderInfoView.as_view(), name='collect-ticket_holder_info'),
    #path('checkout/', views.CheckoutView.as_view(), name='cash_payment'),
    #path('payment/success/', views.PaymentSuccessView.as_view(), name='success'),
]
