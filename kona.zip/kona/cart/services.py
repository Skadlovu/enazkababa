from django.db import transaction
from django.core.exceptions import ValidationError
from .models import Cart, CartItem

class CartService:
    @staticmethod
    def get_or_create_cart(user=None, session_key=None):
        """Get or create a cart for either a user or session"""
        if not (bool(user) ^ bool(session_key)):  # XOR - exactly one should be provided
            raise ValueError("Exactly one of user or session_key must be provided")
        
        cart, _ = Cart.objects.get_or_create(
            user=user,
            session_key=session_key
        )
        return cart
    
    @staticmethod
    def merge_carts(from_cart, to_cart):
        """Merge items from one cart to another"""
        with transaction.atomic():
            for from_item in from_cart.items.all():
                to_item, created = CartItem.objects.get_or_create(
                    cart=to_cart,
                    ticket_details=from_item.ticket_details,
                    defaults={'quantity': from_item.quantity}
                )
                
                if not created:
                    to_item.quantity += from_item.quantity
                    to_item.save()
            
            from_cart.delete()
    
    @staticmethod
    def add_to_cart(cart, ticket_details, quantity):
        """Add items to a cart"""
        with transaction.atomic():
            cart_item, created = CartItem.objects.get_or_create(
                cart=cart,
                ticket_details=ticket_details,
                defaults={'quantity': quantity}
            )
            
            if not created:
                cart_item.quantity += quantity
                cart_item.save()
            
            return {
                'cart_count': cart.total_items,
                'total_price': cart.total_price
            }