from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone
from decimal import Decimal
from kona.gscUtils import OrganiserStorage



class Organiser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='organiser')
    is_profile_complete = models.BooleanField(default=False)
    organisation = models.CharField(max_length=255, blank=True, null=True)
    registration_number=models.CharField( max_length=10,validators=[
            RegexValidator(
                regex=r'^\+?1?\d{9,10}$',
                message="Company registration number: '0000000000'. 10 digits allowed, dont include the last 2 digit."
            )
        ])
    telephone_number = models.CharField(
        max_length=10,
        blank=True,
        null=True,
        validators=[
            RegexValidator(
                regex=r'^\+?1?\d{9,10}$',
                message="Phone number must be entered in the format: '0000000000'. Up to 10 digits allowed."
            )
        ]
    )
    address = models.TextField(blank=True, null=True)
    profile_picture = models.ImageField(storage=OrganiserStorage() ,blank=True, null=True)
    approved = models.BooleanField(default=False)
    social_media = models.URLField(max_length=255, blank=True, null=True)
    date_registered = models.DateTimeField(default=timezone.now)
    is_email_verified = models.BooleanField(default=False)
    verification_status = models.CharField(
        max_length=20,
        choices=[
            ('pending', 'Pending'),
            ('verified', 'Verified'),
            ('rejected', 'Rejected')
        ],
        default='pending'
    )
    featured_organiser = models.BooleanField(default=False)
    commission_rate = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('10.00'))
    last_event_date = models.DateTimeField(blank=True, null=True)
    account_health_score = models.IntegerField(default=100)
    experience_level = models.CharField(
        max_length=15,
        choices=[('beginner', 'Beginner'), ('intermediate', 'Intermediate'), ('experienced', 'Experienced')],
      
    )
    expected_ticket_volume = models.PositiveIntegerField(default=0)
    typical_ticket_price = models.DecimalField(max_digits=8, decimal_places=2,default=0)
    marketing_channels = models.CharField(max_length=255, blank=True, null=True)
    annual_revenue_estimate= models.CharField(max_length=15,)
    financial_strength = models.CharField(max_length=15, choices=[('startup', 'Startup'), ('established', 'Established'), ('non-profit', 'Non-profit')])  # E.g., 'startup', 'established', 'non-profit'
    bank_name = models.CharField(max_length=30, default='your bank')
    bank_account = models.CharField(max_length=20, default='0000000000000')  # Adjusted to CharField for flexibility
    bank_branch = models.CharField(max_length=30, default='your branch')
    bank_branch_code = models.CharField(max_length=10, default='000000')  # Adjusted to CharField for flexibility


    def __str__(self):
        return f"{self.user.username}'s Organiser Profile"


  

    

class SalesReport(models.Model):
    organiser = models.ForeignKey(Organiser, on_delete=models.CASCADE)
    generated_on = models.DateTimeField(auto_now_add=True)
    total_revenue = models.DecimalField(max_digits=10, decimal_places=2)
    total_tickets_sold = models.IntegerField()
    report_details = models.JSONField()  # Stores breakdown details, e.g., by ticket class

    def __str__(self):
        return f"Sales Report for {self.organiser} on {self.generated_on}"
    
 



  
