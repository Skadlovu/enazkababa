from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import views as auth_views
from django.contrib import messages
from django.db import transaction
from django.core.mail import send_mail,EmailMultiAlternatives
from django.conf import settings
from django.utils import timezone
from django.http import JsonResponse
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.decorators import api_view, permission_classes
from django.views.generic import ListView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from ticket.models import Ticket,TicketHolder,TicketCancellation,TicketSales
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .models import Customer,CustomerReward,RewardActivity
from .forms import (
    CustomerProfileForm, CustomerRegistrationForm,
    CustomerEmailForm, PreferencesForm
)
from django.db.models import Sum, Avg,Count
from django.urls import reverse
from event.models import Event
from datetime import timedelta
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from .utils import send_cancellation_email

from .forms import RedeemPointsForm

def redeem_points_view(request):
    customer_reward = CustomerReward.objects.get(customer=request.user.customer)

    if request.method == 'POST':
        form = RedeemPointsForm(request.POST)
        if form.is_valid():
            points_to_redeem = form.cleaned_data['points']
            if customer_reward.redeem_points(points_to_redeem, "Points Redeemed"):
                messages.success(request, f"Successfully redeemed {points_to_redeem} points!")
                return redirect('rewards_dashboard')  # Redirect to the dashboard or another view
            else:
                messages.error(request, "You don't have enough points to redeem.")
        else:
            messages.error(request, "Please enter a valid number of points.")
    else:
        form = RedeemPointsForm()

    return render(request, 'customer_rewards.html', {'form': form, 'customer_reward': customer_reward})


@login_required
def customer_dashboard_view(request):
    # Admin users receive a different message
    if request.user.is_staff:
        return render(request, "customer/dashboard.html", {
            "message": "Admin user dashboard access granted."
        })

    # Get customer data and rewards data
    customer = get_object_or_404(Customer, user=request.user)
    rewards = get_object_or_404(CustomerReward, customer=customer)

    # Prepare the context data for the template
    context = {
        "ticket_data": get_ticket_data(customer),
        "rewards": rewards
    }
    return render(request, "customer/dashboard.html", context)



def get_ticket_data(customer):
    total_tickets = TicketSales.objects.filter(customer=customer).count()

    # Get sales data
    sales = TicketSales.objects.filter(customer=customer)
    total_spent = sales.aggregate(total=Sum('total_price'))['total'] or 0
    avg_price = sales.aggregate(avg=Avg('total_price'))['avg'] or 0

    # Get upcoming events
    upcoming_events = Event.objects.filter(
        ticket_details__ticket_info__ticket_sales__customer=customer,
        event_date__gte=timezone.now()
    ).distinct()

    return {
        "total_tickets": total_tickets,
        "total_spent": total_spent,
        "average_ticket_price": avg_price,
        "total_events": upcoming_events.count(),
        "upcoming_events": [
            {
                "title": event.title,
                "date": event.event_date,
                "venue": event.venue,
            } for event in upcoming_events
        ]
    }

def rewards_explanation_view(request):
    return render(request, "customer/rewards_explaination.html")


@login_required
def combined_rewards_dashboard_view(request):
    customer = get_object_or_404(Customer, user=request.user)
    rewards = get_object_or_404(CustomerReward, customer=customer)

    # Fetch all reward activities for the customer
    reward_history = RewardActivity.objects.filter(customer=customer).order_by('-date')

    # Prepare context for the template
    context = {
        "rewards": rewards,
        "recent_activities": reward_history[:10],  # Show the latest 10 activities
        "reward_history": reward_history,  # Full history for other purposes
    }

    return render(request, "customer/rewards.html", context)

@login_required
def customer_profile_view(request):
    customer = get_object_or_404(Customer, user=request.user)

    # Gather context data
    context = {
        'customer': customer,

    }

    return render(request, 'customer/profile.html', context)


@login_required
def attended_events_view(request):
    # Attempt to retrieve the customer profile for the logged-in user
    try:
        customer = request.user.customer
    except AttributeError:
        # Redirect to profile setup if customer profile is missing
        return redirect('profile_setup')  # Replace 'profile_setup' with the actual view name

    # Filter for past events (only events with a date before today)
    attended_events = TicketHolder.objects.filter(
        ticket_sales__customer=customer,
        ticket_details__event__event_date__lt=timezone.now().date()  # Replace 'event_date' with the actual date field name in the Event model
    ).select_related('ticket_sales__organiser', 'ticket_details__event')

    # Paginate attended events list
    page = request.GET.get('page', 1)
    paginator = Paginator(attended_events, 10)  # 10 events per page

    try:
        attended_events_page = paginator.page(page)
    except PageNotAnInteger:
        attended_events_page = paginator.page(1)
    except EmptyPage:
        attended_events_page = paginator.page(paginator.num_pages)

    # Render the template with attended events context
    return render(request, 'customer/attended_events.html', {
        'attended_events': attended_events_page,})








@login_required
def update_preferences(request):
    if request.method == 'POST':
        form = PreferencesForm(request.POST, instance=request.user.customer)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True, 'message': 'Preferences updated successfully!'})
        return JsonResponse({'success': False, 'errors': form.errors})

    form = PreferencesForm(instance=request.user.customer)
    return render(request, 'customer/update_preferences.html', {'form': form})



def customer_registration(request):
    if request.method == 'POST':
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            customer = Customer.objects.create(user=user)
            rewards=CustomerReward.objects.create(customer=customer)
            customer.save()
            rewards.save()
            send_verification_email(user,request)
            return redirect('customer:email_notice')
    else:
        form = CustomerRegistrationForm()
    return render(request, 'customer/registration.html', {'form': form})

@login_required
def customer_dashboard(request):
    customer_instance = Customer.objects.get(user=request.user)
    return render(request, 'customer/dashboard.html', {'customer': customer_instance})



def registration_complete(request):
    return render(request, 'customer/registration_complete.html')

@login_required
def customer_profile(request):
    customer= Customer.objects.get(user=request.user)
    return render(request, 'customer/profile.html', {'customer':customer})



@login_required
def edit_customer_profile(request):
    customer_instance=Customer.objects.get(user=request.user)

    if request.method == 'POST':
        form = CustomerProfileForm(request.POST, request.FILES, instance=customer_instance)
        form1 = CustomerEmailForm(request.POST, instance=customer_instance)

        # Ensure both forms are valid
        if form.is_valid() and form1.is_valid():
            form.save()
            form1.save()
            return redirect('customer:customer_profiles')
    else:
        form = CustomerProfileForm(instance=customer_instance)
        form1 = CustomerEmailForm(instance=customer_instance)

    context = {
        'form': form,
        'form1': form1,
    }
    return render(request, 'customer/edit_profile.html', context)

def login_view(request):
    return auth_views.LoginView.as_view(template_name='customer/login.html')(request)

def logout_view(request):
    return auth_views.LogoutView.as_view(template_name='customer/logout.html')(request)



@login_required
def my_tickets(request):
    # Retrieve customer record for the logged-in user
    customer = get_object_or_404(Customer, user=request.user)

    # Filter ticket sales for the current customer, ordered by purchase date
    ticket_sales = TicketSales.objects.filter(customer=customer)

    # Exclude tickets that have a related cancellation entry
    tickets = TicketHolder.objects.filter(ticket_sales__in=ticket_sales).exclude(
        ticketcancellation__isnull=False
    )

    # Render the customer's tickets on the my_tickets page
    return render(request, 'customer/my_tickets.html', {
        'tickets': tickets,
        'ticket_sales':ticket_sales,
    })




@login_required
def canceled_tickets(request):
    # Retrieve customer record for the logged-in user
    customer = get_object_or_404(Customer, user=request.user)

    # Fetch canceled tickets associated with the customer, ordered by cancellation date
    canceled_tickets = TicketCancellation.objects.filter(
        ticket_holder__ticket_sales__customer=customer
    ).order_by('-cancelled_at')  # Ensure 'cancelled_at' or similar timestamp exists in the model

    # Paginate the canceled tickets list (e.g., 10 per page)
    paginator = Paginator(canceled_tickets, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Render the canceled tickets with pagination
    return render(request, 'customer/canceled_tickets.html', {
        'canceled_tickets': page_obj  # Use 'page_obj' for pagination
    })


from decimal import Decimal  # Import Decimal for precise decimal calculations

@login_required
def cancel_ticket(request, ticket_holder_id):
    # Retrieve the customer record for the logged-in user
    customer = get_object_or_404(Customer, user=request.user)

    # Find the ticket holder and ensure it belongs to the customer
    ticket_holder = get_object_or_404(TicketHolder, id=ticket_holder_id, ticket_sales__customer=customer)

    # Check if the ticket has already been canceled
    if hasattr(ticket_holder, 'ticketcancellation'):
        messages.error(request, "This ticket has already been canceled.")
        return redirect('customer:my_tickets')

    # Calculate the refund amount as 90% of the ticket price using Decimal
    refund_amount = ticket_holder.price * Decimal('0.9')

    # Create the TicketCancellation entry
    TicketCancellation.objects.create(
        ticket_holder=ticket_holder,
        cancelled_at=timezone.now(),
        refund_amount=refund_amount,
        reason=request.POST.get('reason', '')  # Optional reason from a form
    )

    # Update ticket availability
    ticket_holder.ticket_details.availability.update_tickets_sold(-1)

    # Notify the user
    messages.success(request, "Your ticket has been successfully canceled with a 10% deduction.")
    return redirect('customer:my_tickets')

def verify_email_notice(request):
    return render(request, 'customer/emai_notice.html')



def send_verification_email(user, request):
    token = default_token_generator.make_token(user)
    uid = urlsafe_base64_encode(force_bytes(user.pk))

    # Construct the verification link
    verification_link = request.build_absolute_uri(
        reverse('customer:verify_email', kwargs={'uidb64': uid, 'token': token})
    )

    # Render HTML content for the email
    html_content = render_to_string('customer/email_verification.html', {
        'user': user,
        'verification_link': verification_link
    })


    subject = 'Verify your email address'
    from_email = settings.DEFAULT_FROM_EMAIL
    to = [user.email]

    # Create an email with both plain text and HTML parts
    email = EmailMultiAlternatives(subject, '', from_email, to)
    email.attach_alternative(html_content, "text/html")
    email.send(fail_silently=False)


def verify_email(request, uidb64, token):
    try:
        # Decode the user ID and fetch the user
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = get_object_or_404(User, pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        # Get or create the UserProfile
        profile, created = Customer.objects.get_or_create(user=user)
        profile.is_email_verified = True
        profile.save()

        messages.success(request, 'Email verified! Please log in and complete your profile.')
        return redirect('customer:login')
    else:
        # Invalid token or user not found, handle the error
        messages.error(request, 'Invalid or expired verification link. Please try again.')
        return redirect('customer:login')