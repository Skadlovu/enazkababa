from django.conf import settings
from storages.backends.gcloud import GoogleCloudStorage
from google.oauth2 import service_account
import os


# Use the custom storage class for static and media
Static = lambda: GoogleCloudStorage(location='static')
Media = lambda: GoogleCloudStorage(location='media')



def get_gcs_credentials():
    """Get Google Cloud Storage credentials from service account file"""
    return service_account.Credentials.from_service_account_file(
        os.path.join(settings.BASE_DIR, 'orbital-anchor-414318-e1e139f8bf80.json')
    )

class BaseGoogleCloudStorage(GoogleCloudStorage):
    """Base class for Google Cloud Storage with common configuration"""
    def __init__(self, location=None):
        credentials = get_gcs_credentials()
        super().__init__(
            credentials=credentials,
            bucket_name=settings.GS_BUCKET_NAME,
            location=location,
        )

class BlogImageStorage(BaseGoogleCloudStorage):
    def __init__(self):
        super().__init__(location='media/blog_images')

class UserPictureStorage(BaseGoogleCloudStorage):
    def __init__(self):
        super().__init__(location='media/user_pictures')

class EventPosterStorage(BaseGoogleCloudStorage):
    def __init__(self):
        super().__init__(location='media/event_posters')

class PortraitStorage(BaseGoogleCloudStorage):
    def __init__(self):
        super().__init__(location='media/portraits')

class LandscapeStorage(BaseGoogleCloudStorage):
    def __init__(self):
        super().__init__(location='media/landscapes')

class OrganiserStorage(BaseGoogleCloudStorage):
    def __init__(self):
        super().__init__(location='media/organiser_pictures')

class CategoryPoster(BaseGoogleCloudStorage):
    def __init__(self):
        super().__init__(location='media/category_poster')

