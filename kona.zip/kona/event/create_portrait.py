# portrait_creator.py
import os
from PIL import Image
from django.core.files.base import ContentFile
from tempfile import NamedTemporaryFile
from django.utils.text import slugify

from PIL import Image
from django.core.files.base import ContentFile
from django.utils.text import slugify
from tempfile import NamedTemporaryFile
import os

def create_portrait(event):
    if event.poster and event.poster.file and not event.portrait:
        thumb_path = event.poster.path

        # Open the thumbnail image
        with Image.open(thumb_path) as img:
            # Convert RGBA to RGB if necessary
            if img.mode == 'RGBA':
                # Create a white background
                background = Image.new('RGB', img.size, (255, 255, 255))
                # Paste the image on the background using alpha channel as mask
                background.paste(img, mask=img.split()[3])
                img = background

            # Resize the image to create the portrait
            portrait = img.resize((900, 900))  # Adjust dimensions as needed

            # Save the portrait to a temporary file
            temp_file = NamedTemporaryFile(delete=False)
            portrait.save(temp_file, format='JPEG', quality=90)
            temp_file.close()

            # Read the temporary file and create a ContentFile
            with open(temp_file.name, 'rb') as temp_file_content:
                content_file = ContentFile(temp_file_content.read(), 
                                        name=f'{slugify(event.title)}_portrait.jpg')

            # Update the model's portrait field
            event.portrait.save(content_file.name, content_file, save=True)

            # Remove the temporary file
            os.remove(temp_file.name)