from django.urls import path
from . import views

app_name = 'event'

urlpatterns = [
    path('', views.event_list, name='list'),
    path('<slug:slug>/', views.event_detail, name='detail'),
    path('event/category_list/<str:slug>/', views.categorylist, name='categorylist'),
    path('event/categories/',views.categoryview, name='category'),
    path('event/city_view/',views.cityview, name='city'),
    path('event/city_list/<str:slug>/',views.citylist, name='citylist'),
    path('event/tags/', views.all_tag, name='all_tags'),
    path('event/tags/<slug:slug>/', views.tagged_events, name='tagged_events'),
    path('event/event_date/<int:year>/<int:month>/<int:day>', views.event_date_view, name='event_date_view'),
    path('event/monthly_view/', views.monthly_view, name='monthly_view'),
    path('event/events_today/', views.events_today, name='events_today'),
    path('event/events_this_week/', views.events_this_week, name='events_this_week'),
    path('<int:event_id>/wishlist/', views.toggle_wishlist, name='toggle_wishlist'),
    path('<int:event_id>/like/', views.toggle_like, name='toggle_like'),
    path('<int:event_id>/share/', views.share_event, name='share_event'),
]
