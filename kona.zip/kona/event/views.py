from django.shortcuts import render, get_object_or_404
from .models import Event, Category,EventView
from django.db.models import Min, Max
from taggit.models import Tag
from django.shortcuts import render, get_object_or_404, redirect
from .models import Event, Category,City
from django.core.paginator import Paginator,EmptyPage, PageNotAnInteger
from django.db.models import Count
from django.contrib.auth.decorators import login_required
import random
from django.utils import timezone
from django.contrib.auth.models import User
from datetime import datetime, timedelta
import datetime as time
from django.http import HttpResponseBadRequest,JsonResponse
from django.urls import reverse
from django.views.generic import ListView, CreateView,DetailView
from django.db.models import F, ExpressionWrapper, fields
from django.db.models.functions import Extract
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from taggit.models import Tag
from django.utils.decorators import method_decorator
from django.contrib import messages
import markdown
from django.shortcuts import get_object_or_404, redirect
from django.http import HttpResponseRedirect
from urllib.parse import urlencode




@login_required
def toggle_like(request, event_id):
    event = get_object_or_404(Event, id=event_id)

    if request.user in event.likes.all():
        event.likes.remove(request.user)
        liked = False
    else:
        event.likes.add(request.user)
        liked = True

    return JsonResponse({'liked': liked})


@login_required
def toggle_wishlist(request, event_id):
    event = get_object_or_404(Event, id=event_id)

    if request.user in event.wish_list.all():
        event.wish_list.remove(request.user)
        in_wishlist = False
    else:
        event.wish_list.add(request.user)
        in_wishlist = True

    return JsonResponse({'in_wishlist': in_wishlist})


def share_event(request, event_id):
    event = get_object_or_404(Event, id=event_id)

    # Event details
    event_name = event.title
    event_url = request.build_absolute_uri(event.get_absolute_url())  # The event URL

    # Social media URLs
    twitter_url = f"https://twitter.com/intent/tweet?{urlencode({'text': f'Check out this event: {event_name}', 'url': event_url})}"
    facebook_url = f"https://www.facebook.com/sharer/sharer.php?{urlencode({'u': event_url})}"
    whatsapp_url = f"https://api.whatsapp.com/send?{urlencode({'text': f'Check out this event: {event_name} {event_url}'})}"

    # Check the 'platform' query parameter to decide where to redirect
    platform = request.GET.get('platform', '').lower()

    if platform == 'twitter':
        return HttpResponseRedirect(twitter_url)
    elif platform == 'facebook':
        return HttpResponseRedirect(facebook_url)
    elif platform == 'whatsapp':
        return HttpResponseRedirect(whatsapp_url)
    else:
        # If no platform is selected, or it's invalid, you can redirect to the event detail page
        return redirect('events:event_detail', event_id=event_id)




def event_list(request):
    query = request.GET.get('q')
    category_filter = request.GET.get('category')

    events = Event.objects.filter(status=True, approved=True)
    categories = Category.objects.filter(status=True)


    if query:
        events = events.filter(title__icontains=query)

    if category_filter:
        events = events.filter(category__slug=category_filter)

    for event in events:
        event.lowest_price = event.ticket_details.aggregate(lowest_price=Min('price'))['lowest_price']
        event.highest_price = event.ticket_details.aggregate(highest_price=Max('price'))['highest_price']


    return render(request, 'event/event_list.html', {'events': events, 'categories': categories, 'popular_events': Event.objects.order_by('-views')[:3],  # Add view counter to your model
        'recently_viewed': request.session.get('recently_viewed', [])[:10],})

def event_detail(request, slug):
    event = get_object_or_404(Event, slug=slug, status=True, approved=True)
    event.description=markdown.markdown(event.description)
    performers = event.performers.all()
    event.lowest_price = event.ticket_details.aggregate(lowest_price=Min('price'))['lowest_price']
    event.highest_price = event.ticket_details.aggregate(highest_price=Max('price'))['highest_price']

    if not request.session.session_key:
        request.session.save()
    session_key= request.session.session_key
    is_views=EventView.objects.filter(eventSlug=event.id, sesID=session_key)
    if is_views.count()== 0 and str(session_key) !="None":
        views=EventView()
        views.sesID=session_key
        views.eventSlug=event
        views.save()
        event.views += 1
        event.save()

    return render(request, 'event/event_detail.html', {'event': event, 'performers':performers})



def all_tag(request):
    tags=Tag.objects.all()
    return render(request, 'events/tags.html', {'tags':tags})




def tagged_events(request,slug):
    tag=get_object_or_404(Tag,slug=slug)
    events=Event.objects.filter(tags__in=[tag])
    context={
        'tag': tag,
        'events':events
    }
    return render(request,'events/tagged_events.html',context)


class EventDateView(ListView):
    model = Event
    template_name = 'events/event_date.html'  # Create this template
    context_object_name = 'events'

    def get_queryset(self):
        year = self.kwargs['year']
        month = self.kwargs['month']
        day = self.kwargs['day']
        date = f'{year}-{month:02d}-{day:02d}'  # Format the date
        return Event.objects.filter(event_date=date)



def event_date_view(request, year, month, day):
    # Convert year, month, and day to integers
    year = int(year)
    month = int(month)
    day = int(day)

    # Retrieve events for the specified date
    events = Event.objects.filter(event_date__year=year, event_date__month=month, event_date__day=day)

    # Pass events and date to the template
    context = {
        'events': events,
        'date': f'{year}-{month:02d}-{day:02d}',
    }
    return render(request, 'events/event_date.html', context)


def paginate_events(request, events, page_size):
    paginator = Paginator(events, page_size)
    page = request.GET.get('page')

    try:
        paginated_events = paginator.page(page)
    except PageNotAnInteger:
        # If the page is not an integer, deliver the first page.
        paginated_events = paginator.page(1)
    except EmptyPage:
        # If the page is out of range, deliver the last page of results.
        paginated_events = paginator.page(paginator.num_pages)

    return paginated_events


def all_tag(request):
    tags=Tag.objects.all()
    return render(request, 'events/tags.html', {'tags':tags})




def tagged_events(request,slug):
    tag=get_object_or_404(Tag,slug=slug)
    events=Event.objects.filter(tags__in=[tag])
    context={
        'tag': tag,
        'events':events
    }
    return render(request,'events/tagged_events.html',context)





def categorylist(request, slug):
    template = 'event/category_list.html'


    category = get_object_or_404(Category, slug=slug, status=True)
    events = Event.objects.filter(category=category)

    events_per_page = 20
    paginator = Paginator(events, events_per_page)
    page = request.GET.get('page')

    try:
        events = paginator.page(page)
    except PageNotAnInteger:
        events = paginator.page(1)
    except EmptyPage:
        events = paginator.page(paginator.num_pages)

    context = {'events': events, 'category': category}

    return render(request, template, context)






def recently_posted_events(request):
    recently_posted_events = Event.objects.all().order_by('-upload_date')
    paginated_recently_posted_events=paginate_events(request,recently_posted_events,page_size=18)
    context={
        'recently_posted_events':paginated_recently_posted_events
    }

    return render(request, 'events/recently_posted_events.html', context)






def most_viewed(request):
     most_viewed=Event.objects.all().order_by('-views')
     paginated_most_viewed=paginate_events(request,most_viewed,page_size=9)
     context={
          'most_viewed':paginated_most_viewed
     }
     return render(request,'events/most_viewed.html',context)


def categoryview(request):
    template = 'event/category.html'
    categories = Category.objects.filter(status=True).order_by('name').annotate(events_count=Count('events'))
    paginator = Paginator(categories, 10)  # Display 10 categories per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {'categories': page_obj}
    return render(request, template, context)



def cityview(request):
    template='events/city.html'
    city=City.objects.filter(status=0).order_by('name')
    context={'city':city}
    city_with_count=city.annotate(event_count=Count('events'))
    context={'city':city_with_count}
    return render(request, template, context)




def citylist(request, slug):
    template='events/city_list.html'
    if (City.objects.filter(slug=slug, status=0)):
        events=Event.objects.filter(city__slug=slug)
        city=City.objects.filter(slug=slug).first()
        context={'events':events, 'city':city}

        events_per_page=20
        paginator=Paginator(events, events_per_page)
        page=request.GET.get('page')
        try:
            events=paginator.page('page')
        except PageNotAnInteger:
            events=paginator.page(1)
        except EmptyPage:
            events=paginator.page(paginator.num_pages)
        return render(request, template,context)







def upcoming_events(request):
    current_datetime = timezone.now()

    # Get the upcoming events within the next seven days
    seven_days_from_now = current_datetime + timedelta(days=365)
    upcoming_events = Event.objects.filter(event_date__range=[current_datetime, seven_days_from_now]).order_by('event_date')

    # Calculate the time difference for each event
    for event in upcoming_events:
        event_datetime = timezone.make_aware(datetime.combine(event.event_date, event.event_time), time.timezone.utc)
        event.time_until_start = event_datetime - current_datetime

    return render(request, 'events/upcoming_events.html', {'upcoming_events': upcoming_events})





@method_decorator(login_required, name='dispatch')
class LikeEventView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def post(self, request, event_id):
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            # This is an AJAX request
            event = get_object_or_404(Event, id=event_id)

            if request.user in event.likes.all():
                # User has already liked the event, unlike it
                event.likes.remove(request.user)
                liked = False
            else:
                # User hasn't liked the event, like it
                event.likes.add(request.user)
                liked = True

            response_data = {'liked': liked, 'like_count': event.likes.count()}
            return JsonResponse(response_data)

        # Return a regular HTTP response if it's not an AJAX request
        return redirect('events:event', event_id=event_id)


"""""
@login_required
def submit_comment(request, event_id):
    if request.method == "POST":
        event = get_object_or_404(Event, id=event_id)
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.user = request.user
            comment.event = event
            comment.save()
            # Add debug message
            messages.success(request, 'Comment saved successfully.')
            return redirect('events:event', event_id=event_id)
        else:
            # Add debug message for invalid form
            messages.error(request, 'Form is not valid.')
    else:
        # Add debug message for non-POST request
        messages.error(request, 'Form submission failed: method is not POST.')
    return redirect('events:event', event_id=event_id)
"""

def monthly_view(request):
    # Get the current month and year
    current_date = timezone.now()
    current_month = current_date.month
    current_year = current_date.year

    # Fetch events for the current month and year
    events = Event.objects.filter(event_date__month=current_month, event_date__year=current_year).order_by('event_date')

    # Pass the events and current month/year to the template
    context = {
        'events': events,
        'current_month': current_month,
        'current_year': current_year,
    }
    return render(request, 'events/monthly_view.html', context)




def events_today(request):
    # Get today's date
    today = timezone.now().date()

    # Query events happening today
    events = Event.objects.filter(event_date=today)

    context = {'events': events,'today':today}
    return render(request, 'events/events_today.html', context)




def events_this_week(request):
    # Get today's date
    today = timezone.now().date()

    # Calculate the start of the week as the current day
    start_of_week = today

    # Calculate the end of the week as 6 days after the start of the week
    end_of_week = start_of_week + timedelta(days=6)

    # Query events happening this week
    events = Event.objects.filter(event_date__range=[start_of_week, end_of_week])

    context = {
        'events': events,
        'start_of_week': start_of_week,
        'end_of_week': end_of_week
    }
    return render(request, 'events/events_this_week.html', context)



def trending_events(request):
    # Define weights for each metric (adjust as needed)
    VIEW_WEIGHT = 0.4
    LIKE_WEIGHT = 0.2
    COMMENT_WEIGHT = 0.2
    ATTENDING_WEIGHT = 0.2  # Adjust based on importance

    MAX_ATTENDING = 1000  # Replace 1000 with the actual maximum attendance value
    MAX_VIEWS=1000
    MAX_LIKES=1000
    MAX_COMMENTS=1000



    # Query events and calculate normalized metrics
    events = Event.objects.annotate(
        normalized_views=ExpressionWrapper(F('views') / MAX_VIEWS, output_field=fields.FloatField()),
        normalized_likes=ExpressionWrapper(F('likes') / MAX_LIKES, output_field=fields.FloatField()),
        normalized_comments=ExpressionWrapper(F('comments') / MAX_COMMENTS, output_field=fields.FloatField()),
        normalized_attending=ExpressionWrapper(F('attending') / MAX_ATTENDING, output_field=fields.FloatField()),
    )

    # Calculate popularity score for each event
    events = events.annotate(
        popularity_score=(
            VIEW_WEIGHT * F('normalized_views') +
            LIKE_WEIGHT * F('normalized_likes') +
            COMMENT_WEIGHT * F('normalized_comments') +
            ATTENDING_WEIGHT * F('normalized_attending')
        )
    )

    # Sort events by popularity score (descending)
    trending_events = events.order_by('-popularity_score')

    # Pass trending events to the template
    context = {'trending_events': trending_events}
    return render(request, 'events/trending_events.html', context)




