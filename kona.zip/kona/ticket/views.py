from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import  TicketDetails,TicketHolder,TicketCancellation,TicketSales
from event.models import Event
from django.shortcuts import render, redirect, get_object_or_404
from .forms import TicketHolderForm,TicketPurchaseForm
from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from cart.views import add_to_cart
from django.contrib import messages
from django.http import JsonResponse
from django.core.exceptions import ValidationError
from decimal import Decimal
from django.urls import reverse
from django.contrib import messages
from django.db import transaction




def buy_tickets(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    ticket_details = TicketDetails.objects.filter(event=event)

    if not ticket_details.exists():
        messages.error(request, "No tickets are currently available for this event.")
        return redirect('event:detail', slug=event.slug)

    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 1))

        # Get the selected ticket class instead of using first()
        ticket_class = request.POST.get('ticket_class')
        ticket_details_obj = ticket_details.get(id=ticket_class)

        # Add tickets to cart and return updated cart information
        cart_data = add_to_cart(request, ticket_details_obj.id, quantity)

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'status': 'success',
                'message': f'{quantity} tickets added to cart',
                'cart_count': cart_data['cart_count'],
                'total_price': str(cart_data['total_price']),
                'redirect_url': reverse('cart:cart_view')
            })

        return redirect('cart:cart_view')

    return render(request, 'ticket/buy.html', {'event': event, 'ticket_details': ticket_details})






@login_required
def enter_ticket_holders(request, ticket_sale_id):
    ticket_sale = get_object_or_404(TicketSales, id=ticket_sale_id)
    ticket_holder_formset = forms.inlineformset_factory(
        TicketSales, TicketHolder,
        form=TicketHolderForm,
        extra=ticket_sale.quantity,
        can_delete=False
    )
    if request.method == 'POST':
        formset = ticket_holder_formset(request.POST, instance=ticket_sale)
        if formset.is_valid():
            formset.save()
            # Here you would also generate QR codes and send tickets
            return render(request, 'ticket/confirmation.html')
    else:
        formset = ticket_holder_formset(instance=ticket_sale)

    for form in formset:
        form.helper = FormHelper()
        form.helper.form_method = 'post'
        form.helper.add_input(Submit('submit', 'Submit'))

    return render(request, 'ticket/guests.html', {'formset': formset})



@login_required
def confirmation(request, ticket_sale_id):
    ticket_sale = get_object_or_404(TicketSales, id=ticket_sale_id)

    context = {
        'message': 'Attendees have been added to the guest list. Tickets will be sent to your email shortly.',
        'event_title': ticket_sale.event.title,  # Assuming 'title' is a field in your Event model
        'ticket_details1': ticket_sale.ticket_details.class_name,
        'ticket_details2': ticket_sale.ticket_details.price
    }
    print(context)

    return render(request, 'ticket/confirmation.html', context)



@login_required
def cancel_ticket(request, ticket_holder_id):
    # Get the TicketHolder instance
    ticket_holder = get_object_or_404(TicketHolder, id=ticket_holder_id)

    # Only allow the owner (or admin) to cancel the ticket
    if request.user != ticket_holder.ticket_sales.customer:
        messages.error(request, "You don't have permission to cancel this ticket.")
        return redirect('customer:dashboard')  # Redirect to customer dashboard

    # Ensure the ticket hasn't already been canceled
    if TicketCancellation.objects.filter(ticket_holder=ticket_holder).exists():
        messages.error(request, "This ticket has already been canceled.")
        return redirect('customer:dashboard')

    # Start the cancellation process
    with transaction.atomic():
        # Create a TicketCancellation record
        TicketCancellation.objects.create(
            ticket_holder=ticket_holder,
            refund_amount=ticket_holder.price,  # Optionally process a refund here
            reason=request.POST.get('reason', '')  # Capture the cancellation reason if provided
        )

        # Update the ticket availability
        availability = ticket_holder.ticket_details.availability.first()
        availability.sold -= 1
        availability.save()

        # Optionally: Process refund here (depends on your payment gateway)

        # Notify the user about the cancellation
        messages.success(request, "Your ticket has been canceled and a refund will be processed within 14 days")

    # Fetch updated list of tickets for the user
    customer = request.user
    ticket_sales = TicketSales.objects.filter(customer=customer)
    tickets = TicketHolder.objects.filter(ticket_sales__in=ticket_sales)

    # Render the updated ticket list
    return render(request, 'customer/my_tickets.html', {
        'tickets': tickets
    })
